# CLI Flow

- App Host: unknown
- Review Version: 1
- Steps: 1

## Steps

### 1. S
- Action: click
- Intent: n/a
- Target: button:X
- Page: https://app.test
- Confidence: n/a
