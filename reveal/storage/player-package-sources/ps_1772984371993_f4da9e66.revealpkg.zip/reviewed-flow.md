# Player Session Fixture

- App Host: unknown
- Review Version: 1
- Steps: 2

## Steps

### 1. A
- Action: click
- Intent: n/a
- Target: unknown:n/a
- Page: n/a
- Confidence: n/a

### 2. B
- Action: click
- Intent: n/a
- Target: unknown:n/a
- Page: n/a
- Confidence: n/a
